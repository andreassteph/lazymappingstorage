def hello2():
    print("hello2")
